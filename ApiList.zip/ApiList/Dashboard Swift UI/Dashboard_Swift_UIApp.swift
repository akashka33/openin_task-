//
//  Dashboard_Swift_UIApp.swift
//  Dashboard Swift UI
//
//  Created by Chethan J on 19/06/2023.
//

import SwiftUI

@main
struct Dashboard_Swift_UIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
